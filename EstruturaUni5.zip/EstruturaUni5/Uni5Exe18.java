
import java.util.Scanner;

public class Uni5Exe18 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int totalCanal4 = 0;
        int totalCanal5 = 0;
        int totalCanal9 = 0;
        int totalCanal12 = 0;
        int totalGeral = 0;


        while (true) { 
            System.out.println("Canal: ");
            int canal = sc.nextInt();

            if (canal == 0) {
                break;
            }

            System.out.println("Pessoas assistindo: ");
            int pessoasAssitindo = sc.nextInt();

            switch (canal) {
                case 4:
                    totalCanal4 += pessoasAssitindo;
                    break;
                case 5:
                    totalCanal5 += pessoasAssitindo;
                    break;
                case 9:
                    totalCanal9 += pessoasAssitindo;
                    break;
                case 12:
                    totalCanal12 += pessoasAssitindo;
                    break;
                default:
                    System.out.println("Canal inválido. Os canais válidos são: 4, 5, 9, 12.");
                    continue;
            }
            totalGeral += pessoasAssitindo;
        }

        if (totalGeral > 0) {
            System.out.println("Percentual de audiência do canal 4: " + (totalCanal4 * 100.0) / totalGeral + "%");
            System.out.println("Percentual de audiência do canal 5: " + (totalCanal5 * 100.0) / totalGeral + "%");
            System.out.println("Percentual de audiência do canal 9: " + (totalCanal9 * 100.0) / totalGeral + "%");
            System.out.println("Percentual de audiência do canal 12: " + (totalCanal12 * 100.0) / totalGeral + "%");
        }
        sc.close();
    }
}