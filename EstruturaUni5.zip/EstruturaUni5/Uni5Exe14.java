import java.util.Scanner;

public class Uni5Exe14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int menos10 = 0, entre10e20 = 0, mais20 = 0;
        double totalCompra = 0, totalVenda = 0;

        for (int i = 1; i <= 20; i++) {
            System.out.print("Nome da mercadoria " + i + ": ");
            String nome = sc.next();

            System.out.print("Preço de compra: ");
            double pc = sc.nextDouble();

            System.out.print("Preço de venda: ");
            double pv = sc.nextDouble();

            double lucroPercentual = ((pv - pc) / pc) * 100;

            if (lucroPercentual < 10) {
                menos10++;
            } else if (lucroPercentual <= 20) {
                entre10e20++;
            } else {
                mais20++;
            }

            totalCompra += pc;
            totalVenda += pv;
        }

        double lucroTotal = totalVenda - totalCompra;

        System.out.println("\n=== RELATÓRIO DE LUCRO ===");
        System.out.println("Mercadorias com lucro < 10%: " + menos10);
        System.out.println("Mercadorias com 10% <= lucro <= 20%: " + entre10e20);
        System.out.println("Mercadorias com lucro > 20%: " + mais20);

        System.out.printf("Valor total de compra: R$ %.2f\n", totalCompra);
        System.out.printf("Valor total de venda: R$ %.2f\n", totalVenda);
        System.out.printf("Lucro total: R$ %.2f\n", lucroTotal);

        sc.close();
    }
}
