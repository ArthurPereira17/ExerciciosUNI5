import java.util.Scanner;

public class Uni5Exe30 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("PROBLEMA DA MOCHILA");
        
        System.out.print("Digite o valor inicial (N): ");
        int N = sc.nextInt();
        
        System.out.print("Digite o decremento (K): ");
        int K = sc.nextInt();
        
        System.out.print("Digite o tamanho da mochila (M): ");
        int M = sc.nextInt();
        
        String elementosSequencia = "";
        String elementosMochila = "";
        String elementosFora = "";
        int somaMochila = 0;
        int somaFora = 0;
        int countMochila = 0;
        
        System.out.println("Processando...");
        
        int valorAtual = N;
        while (valorAtual > 0) {
            elementosSequencia += valorAtual + " ";
            
            if (countMochila < M) {
                elementosMochila += valorAtual + " ";
                somaMochila += valorAtual;
                countMochila++;
            } else {
                elementosFora += valorAtual + " ";
                somaFora += valorAtual;
            }
            
            valorAtual -= K;
        }
        
        System.out.println("Elementos da sequência: " + elementosSequencia);
        System.out.println("Elementos na mochila: " + elementosMochila);
        System.out.println("Elementos fora da mochila: " + elementosFora);
        System.out.println("Soma dos elementos na mochila: " + somaMochila);
        System.out.println("Soma dos elementos fora da mochila: " + somaFora);
        
        sc.close();
    }
}