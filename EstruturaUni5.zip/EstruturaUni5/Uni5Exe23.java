import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe23 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("R$ #,##0.00");
        
        System.out.println("RELATÓRIO DE VENDEDORES");
        
        char continuar = 's';
        
        while (continuar == 's' || continuar == 'S') {
            // Entrada de dados do vendedor
            System.out.print("\nNome do vendedor: ");
            String nome = sc.nextLine();
            
            System.out.print("Número de produtos vendidos: ");
            int n = sc.nextInt();
            
            double totalVendas = 0;
            
            // Entrada dos produtos vendidos
            for (int i = 1; i <= n; i++) {
                System.out.println("\nProduto " + i + ":");
                System.out.print("Preço unitário: ");
                double preco = sc.nextDouble();
                
                System.out.print("Quantidade vendida: ");
                int quantidade = sc.nextInt();
                
                totalVendas += preco * quantidade;
            }
            
            // Cálculo do salário (30% das vendas)
            double salario = totalVendas * 0.30;
            
            // Exibição do relatório do vendedor
            System.out.println("RELATÓRIO DO VENDEDOR");
            System.out.println("Nome: " + nome);
            System.out.println("Total de vendas: " + df.format(totalVendas));
            System.out.println("Salário: " + df.format(salario));
            
            // Verifica se deseja continuar
            System.out.print("Deseja digitar os dados de mais um vendedor: s (SIM) / n (NÃO)? ");
            continuar = sc.next().charAt(0);
            sc.nextLine(); // Limpa o buffer
        }
        
        System.out.println("Relatório finalizado.");
        sc.close();    
    }
}
