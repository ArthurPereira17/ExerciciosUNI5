public class Uni5Exe04 {
    public static void main(String[] args) {
        
        double soma = 0.0;

        for (int n = 1; n <= 20; n++) {
            double numerador = 2 * n + 1;
            double denominador = n * (n + 1);
            soma += numerador / denominador;
        }
        System.out.println("A soma dos 20 primeiros termos é: " + soma);
    }
}
