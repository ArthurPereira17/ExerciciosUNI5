import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe27 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("R$ #,##0.00");
        
        int diaMaiorProducao = 0;
        int maiorProducao = 0;
        int totalManha = 0;
        int totalTarde = 0;
        int contadorFuncionarios = 0;
        
        int novoFuncionario = 1;
        
        while (novoFuncionario == 1) {

            int dia;
            while (true) {
                System.out.print("Dia: ");
                dia = sc.nextInt();
                
                if (dia >= 1 && dia <= 30) {
                    break;
                }
                System.out.println("Dia inválido");
            }
            
            System.out.print("Manhã: ");
            int manha = sc.nextInt();
            System.out.print("Tarde: ");
            int tarde = sc.nextInt();
            
            int totalDia = manha + tarde;
            double valorRecebido;
            
            if (dia <= 15) { 
                if (totalDia > 100 && manha >= 30 && tarde >= 30) {
                    valorRecebido = totalDia * 0.80;
                } else {
                    valorRecebido = totalDia * 0.50;
                }
            } else { 
                valorRecebido = (manha * 0.40) + (tarde * 0.30);
            }
            
            if (totalDia > maiorProducao) {
                maiorProducao = totalDia;
                diaMaiorProducao = dia;
            }
            
            totalManha += manha;
            totalTarde += tarde;
            contadorFuncionarios++;
            
            System.out.println(df.format(valorRecebido) + " (valor recebido)");
            
            System.out.print("Novo funcionário: (1.sim 2.não)? ");
            novoFuncionario = sc.nextInt();
        }
        
        System.out.println("Relatório Final:");
        System.out.println("Dia de maior produção: " + diaMaiorProducao + " (" + maiorProducao + " peças)");
        
        if (totalManha > totalTarde) {
            System.out.println("Período com maior produção: Manhã (" + totalManha + " peças)");
        } else if (totalTarde > totalManha) {
            System.out.println("Período com maior produção: Tarde (" + totalTarde + " peças)");
        } else {
            System.out.println("Produção igual em ambos os períodos (" + totalManha + " peças cada)");
        }
        
        System.out.println("Total de funcionários processados: " + contadorFuncionarios);
        
        sc.close();
    }
}