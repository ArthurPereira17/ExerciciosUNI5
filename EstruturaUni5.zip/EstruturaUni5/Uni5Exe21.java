public class Uni5Exe21 {
    public static void main(String[] args) {

        double alturaChico = 1.50;
        double alturaZe = 1.10;

        double crescimentoChico = 0.02;
        double crecscimentoZe = 0.03;

        int anos = 0;

        while (alturaChico > alturaZe) {
            alturaChico += crescimentoChico;
            alturaZe += crecscimentoZe;
            anos++;
        }

        System.out.println("Serão necessários " + anos + " anos para que Zé seja maior que Chico.");
    }
}
