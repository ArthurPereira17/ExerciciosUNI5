public class Uni5Exe11 {
    public static void main(String[] args) {
        int horas = 16;
        int biscoitosQuebrados = 0;
        int quantidadeHora = 0;

        for (int i = 1; i <= horas; i++) {
            if (i == 1) {
                quantidadeHora = 1;
            } else if (i == 2) {
                quantidadeHora = 3;
            } else {
                quantidadeHora = quantidadeHora * 3;
            }

            biscoitosQuebrados += quantidadeHora;
            System.out.println("Hora " + i + ": " + quantidadeHora + " biscoitos quebrados");
        }

        System.out.println("Total de biscoitos quebrados no final do dia: " + biscoitosQuebrados);
    }
}