
import java.util.Scanner;

public class Uni5Exe09 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Quantos alunos tem na sala ?");
        int n = sc.nextInt();

        if (n < 0) {
            System.out.println("O valor de n deve ser maior que 0");
            return;
        }
        String nomes18 = "";
        int contador18 = 0;
        int qtdAlunos20 = 0;

        for(int i = 0; i < n; i++){
            System.out.println("Escreva o nome e idade dos alunos");
            String nome = sc.next();
            int idade = sc.nextInt();

            if (idade == 18) {
                if (contador18 > 0) {
                    nomes18 += " e ";
                }
                nomes18 += nome;
                contador18++;
            }

            if (idade > 20) {
                qtdAlunos20++;
            }
        }

        if (contador18 > 0) {
            System.out.println("Nomes dos alunos que tem 18 anos: " + nomes18);
        }else{ 
            System.out.println("Nenhum aluno tem 18 anos");
        }

        System.out.println("Quantidade de alunos que tem idade acima de 20 anos: " + qtdAlunos20);
        sc.close();
    }
}
