
import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe17 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#0.00");

        int inscricaoMaisAlto = 0;
        double alturaMaisAlto = Double.MIN_VALUE;
        int inscricaoMaisBaixo = 0;
        double alturaMaisBaixo = Double.MAX_VALUE;
        double somaAlturas = 0;
        int totalAtletas = 0;

        while (true) { 
            System.out.println("Inscrição: ");
            int inscricao = sc.nextInt();

            if (inscricao == 0) {
                break;
            }

            System.out.println("Altura: ");
            double altura = sc.nextDouble();

            if (altura > alturaMaisAlto) {
                alturaMaisAlto = altura;
                inscricaoMaisAlto = inscricao;
            }

            if (altura < alturaMaisBaixo) {
                alturaMaisBaixo = altura;
                inscricaoMaisBaixo = inscricao;
            }

            somaAlturas += altura;
            totalAtletas++;
        }

        if (totalAtletas > 0) {
            System.out.println("O atleta mais baixo tem " + alturaMaisBaixo + " e o seu número de inscrição é " + inscricaoMaisBaixo);

            System.out.println("O atleta mais alto tem " + alturaMaisAlto + " e o seu número de inscrição é " + inscricaoMaisAlto);
            
            double mediaAlturas = somaAlturas / totalAtletas;
            System.out.println("A altura média do grupo de atletas é: "+ df.format(mediaAlturas));
        }
        sc.close();
    }
}
