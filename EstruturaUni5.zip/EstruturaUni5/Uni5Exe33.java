import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe33 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00%");
        
        int votosCandidato1 = 0, votosCandidato2 = 0, votosCandidato3 = 0, votosCandidato4 = 0;
        int votosNulos = 0, votosBrancos = 0;
        int totalVotos = 0;
        int voto;
        
        System.out.println("SISTEMA DE VOTAÇÃO");
        System.out.println("1 - Candidato 1");
        System.out.println("2 - Candidato 2");
        System.out.println("3 - Candidato 3");
        System.out.println("4 - Candidato 4");
        System.out.println("5 - Voto Nulo");
        System.out.println("6 - Voto em Branco");
        System.out.println("0 - Encerrar votação");

        do {
            System.out.print("Digite o código do voto: ");
            voto = sc.nextInt();
            
            switch (voto) {
                case 0:
                    break;
                case 1:
                    votosCandidato1++;
                    totalVotos++;
                    break;
                case 2:
                    votosCandidato2++;
                    totalVotos++;
                    break;
                case 3:
                    votosCandidato3++;
                    totalVotos++;
                    break;
                case 4:
                    votosCandidato4++;
                    totalVotos++;
                    break;
                case 5:
                    votosNulos++;
                    totalVotos++;
                    break;
                case 6:
                    votosBrancos++;
                    totalVotos++;
                    break;
                default:
                    System.out.println("Opção incorreta! Digite um código válido.");
                    continue;
            }
            
        } while (voto != 0);

        if (totalVotos > 0) {
            double percentualNulos = (double) votosNulos / totalVotos;
            double percentualBrancos = (double) votosBrancos / totalVotos;
            
            System.out.println("RESULTADO DA ELEIÇÃO");
            System.out.println("Candidato 1: " + votosCandidato1 + " votos");
            System.out.println("Candidato 2: " + votosCandidato2 + " votos");
            System.out.println("Candidato 3: " + votosCandidato3 + " votos");
            System.out.println("Candidato 4: " + votosCandidato4 + " votos");
            System.out.println("Votos Nulos: " + votosNulos);
            System.out.println("Votos em Branco: " + votosBrancos);
            System.out.println("Percentual de Nulos: " + df.format(percentualNulos));
            System.out.println("Percentual de Brancos: " + df.format(percentualBrancos));
            System.out.println("Total de votos: " + totalVotos);
        } else {
            System.out.println("Nenhum voto foi registrado.");
        }
        
        sc.close();
    }
}