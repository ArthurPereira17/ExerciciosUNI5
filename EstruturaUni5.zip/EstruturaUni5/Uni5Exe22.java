public class Uni5Exe22 {
    public static void main(String[] args) {
        
        int anoContratacao = 1995;
        double salario = 2000.0;
        
        double percentualAumento = 0.015;
        int anoAtual = java.time.Year.now().getValue();
        int ano = anoContratacao + 1;

        while(ano <= anoAtual){
            double aumento = salario * percentualAumento;
            salario += aumento;

            System.out.println("Ano: " + ano + " Aumento: " + (percentualAumento * 100) + "%" + " Valor aumento: R$" + aumento + " Novo salário: R$" + salario);

            if (ano >= 1997) {
                percentualAumento *= 2;
            }
            ano++;
        }
        System.out.println("Salário atual em " + anoAtual + ": R$" + salario);
    }
}
