import java.util.Scanner;

public class Uni5Exe31 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite um número inteiro positivo: ");
        int numero = sc.nextInt();
        
        System.out.println("\nNúmero\tDecomposição");
        
        int divisor = 2;
        int numeroAtual = numero;
        
        while (numeroAtual > 1) {
            if (numeroAtual % divisor == 0) {
                System.out.println(numeroAtual + "\t" + divisor);
                numeroAtual /= divisor;
            } else {
                divisor++;
            }
        }
        
        System.out.println("1\t-");
        System.out.println("\nDecomposição completa de " + numero + " em fatores primos.");
        
        sc.close();
    }
}