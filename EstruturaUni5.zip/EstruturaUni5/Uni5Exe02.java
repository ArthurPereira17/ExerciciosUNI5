import java.util.Scanner;

public class Uni5Exe02 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        int somaPares = 0;
        int somaImpares = 0;


        for(int i = 0; i <= 100; i++){
            if (i % 2 == 0) {
                somaPares += i;
            }else{
                somaImpares += i;
            }
        }

        sc.close();

        System.out.println("Soma dos numeros pares: " + somaPares);
        System.out.println("Soma dos numeros ímpares: " + somaImpares);
    }
}
