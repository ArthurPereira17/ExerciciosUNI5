import java.util.Scanner;

public class Uni5Exe32 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite o dia da semana do primeiro dia (1=Domingo,...,7=Sábado): ");
        int primeiroDia = sc.nextInt();
        
        System.out.print("Digite o número de dias no mês: ");
        int numDias = sc.nextInt();
        
        System.out.println("\nD\tS\tT\tQ\tQ\tS\tS");
        
        for (int i = 1; i < primeiroDia; i++) {
            System.out.print("\t");
        }
        
        int diaAtual = 1;
        int diaSemana = primeiroDia;
        
        while (diaAtual <= numDias) {
            System.out.print(diaAtual + "\t");
            
            if (diaSemana == 7) {
                System.out.println();
                diaSemana = 1;
            } else {
                diaSemana++;
            }
            
            diaAtual++;
        }
        
        sc.close();
    }
}