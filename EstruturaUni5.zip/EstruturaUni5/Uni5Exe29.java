import java.util.Scanner;

public class Uni5Exe29 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite o valor a ser sacado: R$");
        int valor = sc.nextInt();
        int valorRestante = valor;
        
        int ced20 = 0, ced10 = 0, ced5 = 0, ced2 = 0, ced1 = 0;
        
        while (valorRestante >= 20) {
            ced20++;
            valorRestante -= 20;
        }
        
        while (valorRestante >= 10) {
            ced10++;
            valorRestante -= 10;
        }
        
        while (valorRestante >= 5) {
            ced5++;
            valorRestante -= 5;
        }
        
        while (valorRestante >= 2) {
            ced2++;
            valorRestante -= 2;
        }
        
        ced1 = valorRestante;
        
        System.out.println("Quantidade mínima de cédulas para R$" + valor + ":");
        
        boolean primeiro = true;
        
        if (ced20 > 0) {
            System.out.print(ced20 + " de R$20");
            primeiro = false;
        }
        if (ced10 > 0) {
            if (!primeiro) System.out.print(" + ");
            System.out.print(ced10 + " de R$10");
            primeiro = false;
        }
        if (ced5 > 0) {
            if (!primeiro) System.out.print(" + ");
            System.out.print(ced5 + " de R$5");
            primeiro = false;
        }
        if (ced2 > 0) {
            if (!primeiro) System.out.print(" + ");
            System.out.print(ced2 + " de R$2");
            primeiro = false;
        }
        if (ced1 > 0) {
            if (!primeiro) System.out.print(" + ");
            System.out.print(ced1 + " de R$1");
        }
        
        System.out.println("Detalhamento:");
        System.out.println(ced20 + " cédula(s) de R$20");
        System.out.println(ced10 + " cédula(s) de R$10");
        System.out.println(ced5 + " cédula(s) de R$5");
        System.out.println(ced2 + " cédula(s) de R$2");
        System.out.println(ced1 + " cédula(s) de R$1");
        
        sc.close();
    }
}