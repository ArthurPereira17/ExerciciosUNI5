
import java.util.Scanner;

public class Uni5Exe19 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        double totalRecebido = 0;

        while (true) {
            System.out.println("Valor da Compra: ");
            double valorCompra = sc.nextDouble();

            if (valorCompra == 0) {
                break;
            }

            double desconto;

            if (valorCompra > 500) {
                desconto = 0.20;
            }else{
                desconto = 0.15;
            }

            double valorPagamento = valorCompra * (1 - desconto);

            totalRecebido += valorPagamento;

            System.out.println("Valor a Pagar: R$" + valorPagamento);
        }

        System.out.println("O valor total recebido foi de R$" + totalRecebido);
        
        sc.close();
    }
}
