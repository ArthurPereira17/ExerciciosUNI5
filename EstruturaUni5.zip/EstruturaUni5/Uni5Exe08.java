
import java.util.Scanner;

public class Uni5Exe08 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Insira um número");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("O valor de n deve ser maior que 0");
            return;
        }

        int menorNegativo = 0;
        int somaPositivos = 0;
        int contadorPositivos = 0;

        for(int i = 1; i <= n; i++){
            System.out.println("Insira " + i + " numero");
            int numero = sc.nextInt();

            if (numero < 0) {
                if (menorNegativo == 0 || numero < menorNegativo ) {
                    menorNegativo = numero;
                }
            }
            else if (numero > 0){
                somaPositivos += numero;
                contadorPositivos++;
            }
        }

        if (menorNegativo != 0) {
            System.out.println("Menor valor negativo:" + menorNegativo );
        }else{
            System.out.println("Nenhum número negativo foi informado");
        }

        if (contadorPositivos > 0) {
            double media = somaPositivos / contadorPositivos;
            System.out.println("Média dos números positivos: " + media);
        } else{
            System.out.println("Não foram informados números positivos");
        }
        sc.close();
    }
}
