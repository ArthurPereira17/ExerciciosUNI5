public class Uni5Exe03 {
    public static void main(String[] args) {
        
        double somatoria = 0.0;

        for(int i = 1; i <= 100; i++){
            somatoria += 1.0/i;
           }
        System.out.println(somatoria);
    }
}
