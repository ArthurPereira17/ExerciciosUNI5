import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe07 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#0.00");

        System.out.println("Insira um número inteiro: ");
        int n = sc.nextInt();

        if (n < 0 ) {
            System.out.println("O número deve ser maior que 0");
            return;
        }

        System.out.print("Digite o 1º número: ");
        double numero = sc.nextDouble();
        double maior = numero;
        double menor = numero;
        
        for (int i = 2; i <= n; i++) {
            System.out.print("Digite o " + i + "º número: ");
            numero = sc.nextDouble();
            
            if (numero > maior) {
                maior = numero;
            }
            if (numero < menor) {
                menor = numero;
            }
        }
        sc.close();
        
        System.out.println("Maior número: "+ df.format(maior));
        System.out.println("Menor número: "+ df.format(menor));
    }
}
