import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe24 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.000");
        
        System.out.print("Informe o limite diário de pesca (em kg): ");
        double limiteKg = sc.nextDouble();
        double limiteGramas = limiteKg * 1000;
        
        double pesoTotal = 0;
        char continuar = 's';
        
        while (continuar == 's' || continuar == 'S') {
            System.out.print("\nInforme o peso do peixe (em gramas): ");
            double pesoPeixe = sc.nextDouble();
            
            pesoTotal += pesoPeixe;
            
            System.out.println("Peso total da pesca: " + df.format(pesoTotal/1000) + " kg");
            
            if (pesoTotal > limiteGramas) {
                System.out.println("\nATENÇÃO: Limite diário de " + limiteKg + " kg excedido!");
                System.out.println("Peso total: " + df.format(pesoTotal/1000) + " kg");
                break;
            }
            
            System.out.print("Deseja informar o peso de mais um peixe: s (SIM) / n (NÃO)? ");
            continuar = sc.next().charAt(0);
        }
        
        if (pesoTotal <= limiteGramas) {
            System.out.println("Pesca encerrada. Peso total: " + df.format(pesoTotal/1000) + " kg");
        }
        
        sc.close();
    }
}