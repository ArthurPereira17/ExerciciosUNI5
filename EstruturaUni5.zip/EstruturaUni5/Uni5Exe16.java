import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe16 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");
        
        double somaAlturasMulheres = 0;
        int quantidadeMulheres = 0;
        double somaAlturasGrupo = 0;
        int quantidadeGrupo = 0;
        
        while (true) {
            System.out.println("Altura: ");
            double altura = sc.nextDouble();
            
            if (altura == 0) {
                break;
            }
            
            System.out.println("Genero: ");
            char genero = sc.next().charAt(0);
            
            somaAlturasGrupo += altura;
            quantidadeGrupo++;
            
            if (genero == 'F' || genero == 'f') {
                somaAlturasMulheres += altura;
                quantidadeMulheres++;
            }
        }
        
        if (quantidadeMulheres > 0) {
            double mediaMulheres = somaAlturasMulheres / quantidadeMulheres;
            System.out.println("A média da altura das mulheres é: " + df.format(mediaMulheres));
        }
        
        if (quantidadeGrupo > 0) {
            double mediaGrupo = somaAlturasGrupo / quantidadeGrupo;
            System.out.println("A média de altura do grupo é: " + df.format(mediaGrupo));
        }
        
        sc.close();
    }
}