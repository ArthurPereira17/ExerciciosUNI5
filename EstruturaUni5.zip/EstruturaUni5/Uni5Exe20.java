import java.util.Scanner;

public class Uni5Exe20 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Insira a massa do material: ");
        double massaInicialKg = sc.nextDouble();
        
        
        double massa = massaInicialKg * 1000;
        int tempo = 0;

        while (massa >= 0.05) {
            massa /= 2;
            tempo += 50;
        }

        double massaFinalKg = massa;

        int minutos = tempo / 60;
        int segundos = tempo % 60;

        System.out.println("Massa inicial: Kg " + massaInicialKg);
        System.out.println("Massa final: Kg " + massaFinalKg + " " +massa);
        System.out.println("Tempo total: " + tempo + " segundos (" + minutos + " minutos e " + segundos + " segundos)");
        
        sc.close();
    }
}
