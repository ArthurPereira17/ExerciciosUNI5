public class Uni5Exe10 {
    public static void main(String[] args) {
        int contador = 0;
        int numero = 1;

        while (contador < 10) {
            int d = (int) Math.log10(numero) + 1;
            
            for (int i = 1; i < d; i++) {
                int divisor = (int) Math.pow(10, i);
                int parte1 = numero / divisor;
                int parte2 = numero % divisor;

                if ((parte1 + parte2) * (parte1 + parte2) == numero) {
                    System.out.println(numero);
                    contador++;
                    break;
                }
            }
            numero++;
        }
    }
}
