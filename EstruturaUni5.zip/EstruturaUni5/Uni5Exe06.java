import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#0.00");
        
        double somaAlturas = 0;
        
        System.out.println("Digite as alturas das pessoas:");
        
        for (int i = 1; i <= 20; i++) {
            System.out.print("Altura da pessoa " + i + ": ");
            double altura = sc.nextDouble();
            somaAlturas += altura;
        }
        
        double media = somaAlturas / 20;
        System.out.printf("A média das alturas é: %.2f", media);

        sc.close();
    }
}
