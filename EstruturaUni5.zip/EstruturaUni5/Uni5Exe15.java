
import java.util.Scanner;

public class Uni5Exe15 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double media = 0, nota1, nota2;

        while (true) {

            System.out.println("Insira o nome do aluno: ");
            String nome = sc.next();

            if (nome.equals("fim")) {
                break;
            }

            System.out.println("Insira a nota 1");
            nota1 = sc.nextDouble();

            System.out.println("Insira a nota 2");
            nota2 = sc.nextDouble();

            media = (nota1 + nota2) / 2;

            System.out.println("A média do(a)" + nome + " é " + media);

        }

        sc.close();
    }
}
