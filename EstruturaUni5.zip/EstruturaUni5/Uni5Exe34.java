import java.util.Scanner;

public class Uni5Exe34 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int contasEncerradas = 0;
        int opcao;
        double diaria_base = 50.00;

        do {
            System.out.println("MENU DO SISTEMA");
            System.out.println("(1) Encerrar a conta de um hóspede");
            System.out.println("(2) Verificar número de contas encerradas");
            System.out.println("(3) Sair");
            System.out.print("Escolha uma opção: ");
            opcao = sc.nextInt();

            if (opcao == 1) {
                double taxaServico;
                
                sc.nextLine(); 
                System.out.print("\nNome do hóspede: ");
                String nome = sc.nextLine();
                
                System.out.print("Número de diárias: ");
                int diarias = sc.nextInt();
                

                if (diarias < 15) {
                    taxaServico = 7.50;
                } else if (diarias == 15) {
                    taxaServico = 6.50;
                } else {
                    taxaServico = 5.00;
                }
                
                double total = (diaria_base + taxaServico) * diarias;
                
                System.out.println("Hóspede: " + nome);
                System.out.println("Total a pagar: R$" + total);
                
                contasEncerradas++;
                
            } else if (opcao == 2) {
                System.out.println("Número de contas encerradas: " + contasEncerradas);
            } else if (opcao == 3) {
                System.out.println("Encerrando o sistema...");
            } else {
                System.out.println("Opção inválida! Tente novamente.");
            }
            
        } while (opcao != 3);

        sc.close();
    }
}