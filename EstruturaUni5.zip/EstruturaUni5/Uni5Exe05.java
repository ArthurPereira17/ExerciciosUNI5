import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe05 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#0.00");

        System.out.println("Digite o valor de n: (maior que 2)");
        int n = sc.nextInt();

        if (n <= 2) {
            System.out.println("O valor de ve ser maior que 2");
            return;
        }

        int termo = 8;
        System.out.print(termo);

        for(int i = 2; i <= n; i++){
            if (i % 2 == 0) {
                termo += 2;
            }else{
                termo *= 2;
            }
            System.out.print(" , "  + termo);
        }
        sc.close();
    }
}
