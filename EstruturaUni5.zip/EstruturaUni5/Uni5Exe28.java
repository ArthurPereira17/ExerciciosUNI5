import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni5Exe28 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00%");
        
        int votosNenhum = 0, votosCPM = 0, votosSkank = 0, votosJota = 0;
        int totalVotos = 0;
        char continuar = 's';
        
        System.out.println("ELEIÇÃO DO MELHOR CONJUNTO DO ANO");
        System.out.println("Códigos dos conjuntos:");
        System.out.println("1 - Nenhum de Nós");
        System.out.println("2 - CPM22");
        System.out.println("3 - Skank");
        System.out.println("4 - Jota Quest");
        
        while (continuar == 's' || continuar == 'S') {
            System.out.print("Mais um voto: s (SIM) / n (NÃO)? ");
            continuar = sc.next().charAt(0);
            
            if (continuar == 'n' || continuar == 'N') {
                break;
            }
            
            System.out.print("Informe o código do conjunto (1-4): ");
            int codigo = sc.nextInt();
            
            switch (codigo) {
                case 1:
                    votosNenhum++;
                    break;
                case 2:
                    votosCPM++;
                    break;
                case 3:
                    votosSkank++;
                    break;
                case 4:
                    votosJota++;
                    break;
                default:
                    System.out.println("Código inválido! Voto não contabilizado.");
                    continue;
            }
            
            totalVotos++;
        }
        
        double percNenhum = (double) votosNenhum / totalVotos;
        double percCPM = (double) votosCPM / totalVotos;
        double percSkank = (double) votosSkank / totalVotos;
        double percJota = (double) votosJota / totalVotos;
        
        String vencedor = "";
        int maiorVotos = Math.max(Math.max(votosNenhum, votosCPM), Math.max(votosSkank, votosJota));
        
        if (maiorVotos == votosNenhum) vencedor = "Nenhum de Nós";
        else if (maiorVotos == votosCPM) vencedor = "CPM22";
        else if (maiorVotos == votosSkank) vencedor = "Skank";
        else vencedor = "Jota Quest";
        
        System.out.println("RESULTADOS DA ELEIÇÃO");
        System.out.println("Nenhum de Nós: " + votosNenhum + " votos (" + df.format(percNenhum) + ")");
        System.out.println("CPM22: " + votosCPM + " votos (" + df.format(percCPM) + ")");
        System.out.println("Skank: " + votosSkank + " votos (" + df.format(percSkank) + ")");
        System.out.println("Jota Quest: " + votosJota + " votos (" + df.format(percJota) + ")");
        System.out.println("\nTotal de votos: " + totalVotos);
        System.out.println("Vencedor: " + vencedor + " com " + maiorVotos + " votos!");
        
        sc.close();
    }
}