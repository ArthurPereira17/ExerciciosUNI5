import java.util.Scanner;

public class Uni5Exe25 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int pontosDireita = 0;
        int pontosEsquerda = 0;
        char ponto;
        
        System.out.println("Registro de Pontos - Partida de Ping-Pong");
        System.out.println("Digite D para ponto do jogador da Direita");
        System.out.println("Digite E para ponto do jogador da Esquerda");
        
        while (true) {
            System.out.print("Próximo ponto (D/E): ");
            ponto = sc.next().toUpperCase().charAt(0);
            
            while (ponto != 'D' && ponto != 'E') {
                System.out.println("Entrada inválida. Digite D ou E.");
                System.out.print("Próximo ponto (D/E): ");
                ponto = sc.next().toUpperCase().charAt(0);
            }
            
            if (ponto == 'D') {
                pontosDireita++;
            } else {
                pontosEsquerda++;
            }
            
            System.out.println("Placar: Direita " + pontosDireita + " x " + pontosEsquerda + " Esquerda");
            
            if ((pontosDireita >= 21 || pontosEsquerda >= 21) && 
                Math.abs(pontosDireita - pontosEsquerda) >= 2) {
                break;
            }
        }
        
        System.out.println("FIM DE JOGO!");
        if (pontosDireita > pontosEsquerda) {
            System.out.println("Vencedor: Jogador da Direita (" + pontosDireita + " a " + pontosEsquerda + ")");
        } else {
            System.out.println("Vencedor: Jogador da Esquerda (" + pontosEsquerda + " a " + pontosDireita + ")");
        }
        
        sc.close();
    }
}