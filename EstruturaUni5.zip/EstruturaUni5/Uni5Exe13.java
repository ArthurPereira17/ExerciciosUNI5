import java.util.Scanner;

public class Uni5Exe13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o número total de paradas: ");
        int totalParadas = sc.nextInt();

        double totalKm = 0, totalCombustivel = 0;

        for (int i = 1; i <= totalParadas; i++) {
            System.out.print("Parada " + i + " - Quilometragem: ");
            double km = sc.nextDouble();

            System.out.print("Parada " + i + " - Combustível (litros): ");
            double litros = sc.nextDouble();

            double kmPorLitro = km / litros;
            System.out.printf("Parada %d: %.2f km por litro\n", i, kmPorLitro);

            totalKm += km;
            totalCombustivel += litros;
        }

        double mediaGeral = totalKm / totalCombustivel;
        System.out.printf("Quilometragem média obtida por litro: %.2f\n", mediaGeral);

        sc.close();
    }
}
