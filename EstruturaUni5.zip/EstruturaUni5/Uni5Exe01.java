import java.util.Scanner;

public class Uni5Exe01{
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        
        for(int i = 1; i < 20; i++){
            System.out.println("Insira um número: ");
            int numeros = sc.nextInt();
            if (numeros % 2 == 0){
                System.out.println("Par");
            }else{
                System.out.println("Impar");
            }
        }

        sc.close();

    }
}